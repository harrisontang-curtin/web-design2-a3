console.log("JavaScript is working!");

// const img = document.querySelector('img');

// img.addEventListener('click', (event) => {
//     img.style.transform = "scale(1.2)";

// })
